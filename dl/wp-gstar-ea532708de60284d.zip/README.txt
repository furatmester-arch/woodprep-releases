WoodPrep - GstarCAD 2027
========================

TELEPÍTÉS (gépenként és Windows-felhasználónként egyszer)
---------------------------------------------------------
1. Jobb kattintás a letöltött zip fájlra -> Tulajdonságok ->
   pipálja be a "Tiltás feloldása" négyzetet -> OK.
2. Csomagolja ki a zipet, például az Asztalra.
3. Indítsa el a GstarCAD 2027-et, és nyisson meg vagy hozzon létre egy rajzot.
4. Írja be: NETLOAD, majd nyomjon Entert.
5. Válassza ki a 06_Felder_Gstar.dll fájlt.
6. Ha a GstarCAD biztonsági kérdést tesz fel, engedélyezze a betöltést.
7. Megjelenik a WoodPrep szalag, és a parancssorban ez a sor:
   "WoodPrep: Beállítva, a GstarCAD mostantól magától betölti."
8. Új gépen a regisztrációs ablak is megnyílik: adja meg az adatait.
   Jóváhagyás után e-mailt kap, utána indítsa újra a GstarCAD-et.

Ezután a NETLOAD-ra nincs többé szükség, a kicsomagolt mappa törölhető.


HA NEM MŰKÖDIK
--------------
- Nincs WoodPrep szalag: ellenőrizze, hogy nyitva van-e egy rajz.
- A gomboknak nincs hatása: nézze meg a parancssor üzenetét, és küldje el nekünk.
- A 443-as portnak nyitva kell lennie.

Kapcsolat: support@woodprep.eu
