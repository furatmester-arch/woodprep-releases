========================================================
  WoodPrep - AutoCAD plug-in installation
========================================================

Requires: AutoCAD 2025, 2026 or 2027 (64-bit, Windows).
Free to try for 14 days.


INSTALLATION - two ways, pick whichever you prefer
--------------------------------------------------------

  A) ONE CLICK
     1. Extract this zip into a folder.
     2. Close AutoCAD.
     3. Run "Install.cmd" (double-click).
     4. Start AutoCAD.

  B) MANUAL - nothing is executed
     1. Extract this zip into a folder.
     2. Close AutoCAD.
     3. Copy the ".bundle" folder into:

          %APPDATA%\Autodesk\ApplicationPlugins\

        (You can paste the line above into the address
         bar of File Explorer.)
     4. Start AutoCAD.

  Install.cmd does exactly this and nothing more - it
  copies one folder. It is a plain text file, so you can
  open it in Notepad and check before running it.

  Either way, the plug-in loads automatically on start -
  NETLOAD is not needed. A "WoodPrep" tab appears on the
  ribbon. It is also available from the classic menu bar,
  if you work without the ribbon.


FIRST START
--------------------------------------------------------
  A registration window opens the first time you start it:
  enter your name and e-mail address. You will receive a
  code by e-mail; type it in and the 14-day trial begins.

  You can also choose the language (English / Hungarian) here.


EXCEL WORKBOOK
--------------------------------------------------------
  The companion workbook is downloaded next to your saved
  drawing, so the DWG and its cutting list stay together
  in the same folder.

  There is nothing to configure - you never have to decide
  where the file goes, and you never have to look for it.

  Save the drawing first, then open the workbook from the
  same folder and import the part data with one click.


IF WINDOWS SHOWS A WARNING
--------------------------------------------------------
  Fastest fix, BEFORE extracting:
    - Right-click the downloaded zip -> Properties
    - Tick "Unblock" at the bottom -> OK
    - Only then extract it.

  Or, if the warning already appeared: "More info"
  -> "Run anyway".


UNINSTALL
--------------------------------------------------------
  Delete this folder:

    %APPDATA%\Autodesk\ApplicationPlugins\<the .bundle folder>


REQUIREMENTS
--------------------------------------------------------
  Outbound port 443 must be open for licence activation.


CONTACT
--------------------------------------------------------
  https://woodprep.eu
  support@woodprep.eu
