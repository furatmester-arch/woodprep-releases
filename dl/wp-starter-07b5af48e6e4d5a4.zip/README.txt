========================================================
  WoodPrep - AutoCAD plug-in installation
========================================================

Requires: AutoCAD 2021 - 2027 (64-bit, Windows).
Free to try for 14 days.

This zip contains two folders - pick the one for YOUR
AutoCAD version:

  WoodPrep_AutoCAD_2025-2027.bundle   -> AutoCAD 2025, 2026, 2027
  WoodPrep_AutoCAD_2021-2024.bundle   -> AutoCAD 2021, 2022, 2023, 2024

(If you are not sure, you can copy both - AutoCAD loads
 only the one that matches its version.)


INSTALLATION
--------------------------------------------------------
  1. Close AutoCAD.
  2. Right-click the downloaded zip -> Properties ->
     tick "Unblock" at the bottom -> OK.
  3. Extract the zip.
  4. Copy the folder for your AutoCAD version into:

          %APPDATA%\Autodesk\ApplicationPlugins\

     (Paste the line above into the address bar of
      File Explorer and press Enter.)
  5. Start AutoCAD and open or create a drawing.

  The plug-in loads automatically - NETLOAD is not needed.
  A "WoodPrep" tab appears on the ribbon.


UPDATING FROM AN EARLIER VERSION
--------------------------------------------------------
  If the ApplicationPlugins folder already contains a
  folder named "02_Standard.bundle", delete it first.
  Otherwise AutoCAD loads the old version as well and you
  see a second WoodPrep tab.


FIRST START
--------------------------------------------------------
  A registration window opens: enter your name and e-mail
  address. You will receive a code by e-mail; type it in
  and the 14-day trial begins.

  You can also choose the language (English / Hungarian).


UNINSTALL
--------------------------------------------------------
  Delete the WoodPrep folder from:

    %APPDATA%\Autodesk\ApplicationPlugins\


REQUIREMENTS
--------------------------------------------------------
  Outbound port 443 must be open for licence activation.


CONTACT
--------------------------------------------------------
  https://woodprep.eu
  support@woodprep.eu
