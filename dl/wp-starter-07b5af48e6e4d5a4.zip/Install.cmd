@echo off
setlocal enabledelayedexpansion
chcp 1250 >nul
title WoodPrep - installation

rem ===== WoodPrep AutoCAD plug-in - one click installer (AutoCAD 2021-2027) =====
rem Copies the .bundle folder next to this file into the user's
rem AutoCAD ApplicationPlugins folder. AutoCAD loads it
rem automatically at startup - NETLOAD is not needed.
rem
rem After copying it removes the "downloaded from the internet" mark from
rem the copied files (Unblock-File). AutoCAD 2021-2024 runs .NET Framework
rem 4.8, which may refuse to load a marked DLL.

set "AP=%APPDATA%\Autodesk\ApplicationPlugins"

echo ================================================
echo   WoodPrep - AutoCAD plug-in installation
echo   for AutoCAD 2021 - 2027
echo ================================================
echo.
echo IMPORTANT: please close AutoCAD before installing.
echo.
pause
echo.

if not exist "%AP%" mkdir "%AP%"

rem The earlier package used the folder name 02_Standard.bundle (with an
rem outdated WoodPrep.cuix). Remove it, otherwise AutoCAD would load both.
if exist "%AP%\02_Standard.bundle" (
  echo Removing previous version: 02_Standard.bundle
  rmdir /s /q "%AP%\02_Standard.bundle"
)

set "DB=0"
for /d %%B in ("%~dp0*.bundle") do (
  set "DB=1"
  echo Installing: %%~nxB
  if exist "%AP%\%%~nxB" rmdir /s /q "%AP%\%%~nxB"
  xcopy "%%~fB" "%AP%\%%~nxB\" /e /i /y >nul
  if errorlevel 1 (
    echo    ERROR while copying.
  ) else (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%AP%\%%~nxB' -Recurse -File | Unblock-File" >nul 2>&1
    echo    done.
  )
)

echo.
if "%DB%"=="0" (
  echo ERROR: no .bundle folder found next to this installer.
  echo Please extract the COMPLETE zip into a folder first,
  echo then run this file from there.
) else (
  echo ================================================
  echo   DONE.
  echo ================================================
  echo.
  echo   Start AutoCAD (2021 - 2027). The matching version loads automatically.
  echo   A "WoodPrep" tab appears on the ribbon.
  echo.
  echo   On first start a registration window opens.
)
echo.
pause
