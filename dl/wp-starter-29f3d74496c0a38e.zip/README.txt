WoodPrep - AutoCAD plug-in
==========================

Folders:
  AutoCAD_2025-2027\WoodPrep.dll                     -> AutoCAD 2025, 2026, 2027
  AutoCAD_2021-2024\02_Standard_14day_Desk_2024.dll  -> AutoCAD 2021, 2022, 2023, 2024


INSTALL WITH NETLOAD
--------------------
1. Right-click the downloaded zip -> Properties -> tick "Unblock" -> OK.
2. Extract the zip to a permanent folder, e.g. C:\WoodPrep
   (do not delete it later - AutoCAD loads the DLL from there).
3. Start AutoCAD and open or create a drawing.
4. Type NETLOAD and press Enter.
5. Select the DLL for your AutoCAD version from the folder above.
6. If AutoCAD shows a security warning, click "Always Load".
7. The WoodPrep tab appears and the registration window opens:
   enter your name and e-mail, then the code you receive by e-mail.


LOAD AUTOMATICALLY AT EVERY START (optional)
--------------------------------------------
Type APPLOAD -> Startup Suite -> Contents... -> Add...
-> select the same DLL -> Close.


IF YOU HAD AN EARLIER VERSION
-----------------------------
Close AutoCAD, paste this into the File Explorer address bar:
    %APPDATA%\Autodesk\ApplicationPlugins
and delete the folder "02_Standard.bundle".


Port 443 must be open.  Contact: support@woodprep.eu
