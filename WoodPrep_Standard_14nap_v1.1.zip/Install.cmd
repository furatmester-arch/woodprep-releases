@echo off
setlocal enabledelayedexpansion
chcp 1250 >nul
title WoodPrep - telepites

rem ===== WoodPrep AutoCAD bovitmeny - egykattintasos telepito =====
rem A telepito mellett levo .bundle mappat masolja a felhasznalo
rem AutoCAD ApplicationPlugins mappajaba. AutoCAD indulaskor
rem automatikusan betolti - NETLOAD nem kell.

set "AP=%APPDATA%\Autodesk\ApplicationPlugins"

echo ================================================
echo   WoodPrep - AutoCAD bovitmeny telepitese
echo ================================================
echo.
echo FONTOS: a telepites elott zard be az AutoCAD-et.
echo.
pause
echo.

set "DB=0"
for /d %%B in ("%~dp0*.bundle") do (
  set "DB=1"
  echo Telepites: %%~nxB
  if exist "%AP%\%%~nxB" rmdir /s /q "%AP%\%%~nxB"
  xcopy "%%~fB" "%AP%\%%~nxB\" /e /i /y >nul
  if errorlevel 1 (
    echo    HIBA a masolas kozben.
  ) else (
    echo    kesz.
  )
)

echo.
if "%DB%"=="0" (
  echo HIBA: nem talaltam .bundle mappat a telepito mellett.
  echo Elobb csomagold ki a TELJES zip-et egy mappaba,
  echo majd onnan inditsd ezt a fajlt.
) else (
  echo ================================================
  echo   KESZ.
  echo ================================================
  echo.
  echo   Inditsd el az AutoCAD 2025/2026-ot.
  echo   A szalagon megjelenik a "WoodPrep" ful.
  echo.
  echo   Elso inditaskor regisztracios ablak nyilik:
  echo   nev + email, majd emailben kapott kod.
)
echo.
pause
