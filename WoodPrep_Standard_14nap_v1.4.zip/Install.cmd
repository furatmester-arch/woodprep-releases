@echo off
setlocal enabledelayedexpansion
title WoodPrep - installation

rem ===== WoodPrep AutoCAD plug-in - one-click installer =====
rem Copies the .bundle folder next to this script into the user's
rem AutoCAD ApplicationPlugins folder. AutoCAD loads it automatically
rem on start - NETLOAD is not needed.

set "AP=%APPDATA%\Autodesk\ApplicationPlugins"

echo ================================================
echo   WoodPrep - AutoCAD plug-in installation
echo ================================================
echo.
echo IMPORTANT: close AutoCAD before installing.
echo.
pause
echo.

set "DB=0"
for /d %%B in ("%~dp0*.bundle") do (
  set "DB=1"
  echo Installing: %%~nxB
  if exist "%AP%\%%~nxB" rmdir /s /q "%AP%\%%~nxB"
  xcopy "%%~fB" "%AP%\%%~nxB\" /e /i /y >nul
  if errorlevel 1 (
    echo    ERROR while copying.
  ) else (
    echo    done.
  )
)

echo.
if "%DB%"=="0" (
  echo ERROR: no .bundle folder found next to this installer.
  echo Extract the COMPLETE zip into a folder first,
  echo then run this file from there.
) else (
  echo ================================================
  echo   FINISHED.
  echo ================================================
  echo.
  echo   Start AutoCAD 2025/2026.
  echo   A "WoodPrep" tab appears on the ribbon.
  echo.
  echo   On first start a registration window opens:
  echo   name + e-mail, then the code you receive by e-mail.
)
echo.
pause
